package models;

public class Inicio {
}
